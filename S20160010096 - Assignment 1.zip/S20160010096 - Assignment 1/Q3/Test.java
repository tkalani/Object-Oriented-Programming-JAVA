class Test
{
int tempa, tempb;
Test(int a, int b) {
tempa = a;
tempb = b; }
public static void main (String args[]) {
Test t = new Test();
System.out.println(t.tempa+" "+t.tempb); }
}